{{/*
Expand the name of the chart.
*/}}
{{- define "indoc-coref.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "indoc-coref.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "indoc-coref.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "indoc-coref.labels" -}}
helm.sh/chart: {{ include "indoc-coref.chart" . }}
{{ include "indoc-coref.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "indoc-coref.selectorLabels" -}}
app.kubernetes.io/name: {{ include "indoc-coref.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "indoc-coref.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "indoc-coref.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Define the image and tag to use for the Indoc-Coref Server container
*/}}
{{- define "indoc-coref.image" -}}
{{- include "indoc-coref.image.registry" . -}}
{{- print  .Values.image.repository ":" ( default .Chart.AppVersion .Values.image.tag ) }}
{{- end }}

{{/*
Define the registry for the Indoc-Coref Server container
*/}}
{{- define "indoc-coref.image.registry" -}}
{{- $registry := ((.Values.global).imageRegistry | default .Values.image.registry) -}}
{{- if $registry  -}}
{{- print $registry -}}
{{- if not (hasSuffix "/" $registry) -}}
{{- print "/" -}}
{{- end -}}
{{- end -}}
{{- end -}}

